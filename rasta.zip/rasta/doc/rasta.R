### R code from vignette source 'rasta.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: options
###################################################
options(prompt = "R> ", digits = 4, show.signif.stars = FALSE)


###################################################
### code chunk number 2: demo (eval = FALSE)
###################################################
## demo("Lesson_1_demo", package = "RASTA")


